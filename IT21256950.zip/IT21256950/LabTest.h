#pragma once
#include  "Payment.h"
#include  "LabReport.h"
#define SIZE 2

class LabTest
{
private:
	LabReport *l_report[SIZE];
	Payment *payment[SIZE];
	char testID[5];
	char testName[20];
	double testPrice;

public:
	LabTest();
	LabTest(int lrep1, int lrep2, char t_ID[], char t_Name[], double t_Price);
	void addPayment(Payment *payment1, Payment *payment2);
	void DisplayTestDetails();
	~LabTest();
};

