#include "stdafx.h"
#include "LabTest.h"
#include <cstring>
#include <iostream>
using namespace std;


LabTest::LabTest()
{
	l_report[0] = new LabReport(101);
	l_report[1] = new LabReport(102);
	strcpy_s(testID, "T2314");
	strcpy_s(testName, "PCR");
	testPrice = 1500.0;
}

LabTest::LabTest(int lrep1, int lrep2, char t_ID[], char t_Name[], double t_Price)
{
	l_report[0] = new LabReport(lrep1);
	l_report[1] = new LabReport(lrep2);
	strcpy_s(testID, t_ID);
	strcpy_s(testName, t_Name);
	testPrice = t_Price;
}

void LabTest::addPayment(Payment * payment1, Payment * payment2)
{
	payment[0] = payment1;
	payment[1] = payment2;
}

void LabTest::DisplayTestDetails()
{
	for (int i = 0; i < SIZE; i++) {
		l_report[i]->DisplayReportDetails();
	}
	for (int i = 0; i < SIZE; i++) {
		payment[i]->DisplayPaymentDetails();
	}
}


LabTest::~LabTest()
{
	cout << "LabReport close" << endl;
	for (int i = 0; i < SIZE; i++) {
		delete l_report[i];
	}
	for (int i = 0; i < SIZE; i++) {
		delete payment[i];
	}
	
}
